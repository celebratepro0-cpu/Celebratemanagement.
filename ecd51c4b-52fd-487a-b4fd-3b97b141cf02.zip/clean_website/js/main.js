// Celebrity Booking Platform - Main JavaScript

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeSearch();
    initializeSmoothScrolling();
    initializeMobileMenu();
    setActiveNavLink();
});

// Search functionality
function initializeSearch() {
    const searchInput = document.getElementById('searchInput');
    if (!searchInput) return;
    
    const servicesGrid = document.getElementById('servicesGrid');
    const serviceCards = servicesGrid.querySelectorAll('.service-card');

    searchInput.addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase().trim();
        
        serviceCards.forEach(card => {
            const title = card.querySelector('h3').textContent.toLowerCase();
            const description = card.querySelector('p').textContent.toLowerCase();
            
            if (title.includes(searchTerm) || description.includes(searchTerm)) {
                card.style.display = 'block';
                card.classList.add('fade-in');
            } else {
                card.style.display = 'none';
            }
        });
    });
}

// Booking functionality - redirect to booking page
function bookService(serviceId) {
    window.location.href = `booking.html?service=${serviceId}`;
}

// Contact form submission
function submitContact(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const name = formData.get('name');
    const email = formData.get('email');
    const message = formData.get('message');
    
    // Show success message
    const form = event.target;
    const successDiv = document.createElement('div');
    successDiv.className = 'alert alert-success';
    successDiv.innerHTML = `<strong>Thank you ${name}!</strong> Your message has been received. We'll get back to you at ${email} within 24-48 hours.`;
    
    form.insertBefore(successDiv, form.firstChild);
    form.reset();
    
    // Remove message after 5 seconds
    setTimeout(() => {
        successDiv.remove();
    }, 5000);
}

// Smooth scrolling for navigation links
function initializeSmoothScrolling() {
    const navLinks = document.querySelectorAll('a[href^="#"]');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                e.preventDefault();
                
                const navbarHeight = document.querySelector('.navbar').offsetHeight;
                const targetPosition = targetSection.offsetTop - navbarHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
}

// Mobile menu toggle
function initializeMobileMenu() {
    const navbar = document.querySelector('.navbar');
    const navMenu = document.querySelector('.nav-menu');
    
    // Only add mobile menu button on smaller screens
    if (window.innerWidth <= 768) {
        // Check if button already exists
        if (!document.querySelector('.mobile-menu-btn')) {
            const menuButton = document.createElement('button');
            menuButton.className = 'mobile-menu-btn';
            menuButton.innerHTML = '☰';
            menuButton.style.cssText = `
                display: block;
                background: none;
                border: none;
                color: white;
                font-size: 1.5rem;
                cursor: pointer;
                padding: 0.5rem;
                position: absolute;
                right: 20px;
                top: 50%;
                transform: translateY(-50%);
            `;
            
            menuButton.addEventListener('click', function() {
                navMenu.classList.toggle('mobile-active');
                
                if (navMenu.classList.contains('mobile-active')) {
                    navMenu.style.display = 'flex';
                    navMenu.style.flexDirection = 'column';
                    navMenu.style.position = 'absolute';
                    navMenu.style.top = '100%';
                    navMenu.style.left = '0';
                    navMenu.style.right = '0';
                    navMenu.style.background = 'var(--dark-color)';
                    navMenu.style.padding = '1rem';
                    navMenu.style.gap = '0.5rem';
                } else {
                    navMenu.style.display = '';
                    navMenu.style.position = '';
                }
            });
            
            navbar.querySelector('.nav-container').appendChild(menuButton);
        }
    }
}

// Set active nav link based on current page
function setActiveNavLink() {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (href === currentPage || (currentPage === '' && href === 'index.html')) {
            link.style.background = 'rgba(255, 255, 255, 0.1)';
        }
    });
}

// Handle window resize
window.addEventListener('resize', function() {
    initializeMobileMenu();
});